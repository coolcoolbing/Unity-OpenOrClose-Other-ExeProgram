﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CoreAudioApi;
using System.IO;
using System.Threading;

namespace AudioControl
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        MMDevice device;
        AudioSessionManager audioSessionManager;
        SessionCollection sessions;

        /// <summary>
        /// 开启程序时就执行
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
            
            //初始化设备
            MMDeviceEnumerator devEnum = new MMDeviceEnumerator();
            device = devEnum.GetDefaultAudioEndpoint(EDataFlow.eRender, ERole.eMultimedia);

            //label1.Text = "当前音量：" + Convert.ToInt32(device.AudioEndpointVolume.MasterVolumeLevelScalar * 100.0f); 

            
            //获取所有程序声音的管理器
            audioSessionManager = device.AudioSessionManager;
            sessions = audioSessionManager.Sessions;

            //显示所有程序的SessionIdentifier
            label1.Text ="当前应用音量的个数"+ audioSessionManager.Sessions.Count+
                "。当前所有音频程序的SessionIdentifier:\n";
            for (int i = 0; i < audioSessionManager.Sessions.Count; i++)
            {
                AudioSessionControl app = sessions[i];
                string sIdentifier = app.SessionIdentifier;
                label1.Text += app.SessionIdentifier + "\n";
            }

            GetExeName();        //获得需要静音的exe程序名称，并对其静音
        }

        /// <summary>
        /// 找到我们要找的程序
        /// </summary>
        /// <param name="exeName">exe程序的名字</param>
        /// <param name="isMute">静音还是不静音</param>
        private void FindTheApplication(string exeName,bool isMute)
        {
            
            //判断这个程序是不是我们要的
            for (int i=0;i< audioSessionManager.Sessions.Count;i++)
            {
                AudioSessionControl app = sessions[i];
                string sIdentifier = app.SessionIdentifier;
                
                if (isTheAppWeNeed(sIdentifier,exeName))
                {
                    //app.SimpleAudioVolume.MasterVolume=0;

                    app.SimpleAudioVolume.Mute = isMute;//设置静音状态
                    if (isMute)
                    {
                        label3.Text = "静音成功!";
                    }
                    else
                    {
                        label3.Text = "取消静音成功!";
                    }
                    
                    return;
                }
            }
            label3.Text = "没有找到该exe程序的音量控制实体";
        }

        /// <summary>
        /// 根据identify判断是不是我们要找的程序
        /// </summary>
        /// <param name="sIdentifier"></param>
        /// <returns></returns>
        private bool isTheAppWeNeed(string sIdentifier,string exeName)
        {
            if (exeName== "") { return false; }
            if(sIdentifier.Contains(exeName+ ".exe"))//判断Identifier中是不是我们需要的程序
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 从txt文件中获得要静音的exe程序的名字
        /// </summary>
        void GetExeName()
        {
            string exeName=File.ReadAllText("ExeNeedMute.txt");
            label4.Text =exeName;
            if (exeName == "") { label4.Text = "exe名称为空，检查是否有在txt设置exe程序的名称"; }
            else
            {
                FindTheApplication(exeName, true);
                AppDomain.CurrentDomain.UnhandledException += delegate {
                    FindTheApplication(label4.Text, false);
                    throw new Exception();
                };
            }


            //开启一个线程
            
            Thread a = new Thread(Get);
            a.IsBackground = true;
            a.Start();
        }

        void Get()
        {
            while (true)
            {
                if ((File.ReadAllText("123.txt") == "close"))
                {
                    File.WriteAllText("123.txt", "open");

                    Thread b=new Thread(ReserveAudio);
                    b.IsBackground = true;
                    b.Start();
                }
                Thread.Sleep(500);
            }
        }

        void ReserveAudio()
        {
            FindTheApplication(label4.Text, false);
        }
        
        /// <summary>
        /// 本程序关闭时对exe程序恢复音量
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            FindTheApplication(label4.Text, false);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //FindTheApplication(label4.Text, false);
        }
    }
}
